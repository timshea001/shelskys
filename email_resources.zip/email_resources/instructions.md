info from client: Today - Now Taking Hanukkah, Christmas, and New Year’s Eve/Day, & Festivus (for the rest of us) Orders… List the deadlines which are on top of the page 1 and 2 of the below jpegs.  I often use the holiday menus as the image in the emails I send, so that’s an option I suppose.

Photos to showcase…. Latkes, caviar images, balik Tsar’s cut salmon, Hanukkah candles, dreidels, gelt… Lemme see if I have some more photos to add to the google folder too

main lander: https://shelskys.com/product-category/christmas-new-year/

deadlines found: deadline.jpeg
